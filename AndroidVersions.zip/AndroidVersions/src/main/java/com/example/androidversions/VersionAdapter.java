package com.example.androidversions;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import com.example.androidversions.AndroidVersion;

public class VersionAdapter extends RecyclerView.Adapter<VersionAdapter.VersionViewHolder> {
    private List<AndroidVersion> versionList;
    private Context context;
    public VersionAdapter(List<AndroidVersion> versionList, Context context) {
        this.versionList = versionList;
        this.context = context;
    }
    @NonNull
    @Override
    public VersionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_android_version, parent, false);
        return new VersionViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull VersionViewHolder holder, int position) {
        AndroidVersion currentVersion = versionList.get(position);
        holder.tvCodeName.setText(currentVersion.getCodeName());
        holder.tvVersionNumber.setText("Version: " + currentVersion.getVersion());
        holder.imgVersionLogo.setImageResource(currentVersion.getImageResId());
        if (position % 2 == 0) {
            holder.cardView.setCardBackgroundColor(android.graphics.Color.parseColor("#cacaca"));
        } else {
            holder.cardView.setCardBackgroundColor(android.graphics.Color.parseColor("#FFFFFF"));
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = "You selected: " + currentVersion.getCodeName() + " (" + currentVersion.getVersion() + ")";
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
            }
        });
    }
    @Override
    public int getItemCount() {
        return versionList != null ? versionList.size() : 0;
    }
    public static class VersionViewHolder extends RecyclerView.ViewHolder {
        ImageView imgVersionLogo;
        TextView tvCodeName;
        TextView tvVersionNumber;
        androidx.cardview.widget.CardView cardView;
        public VersionViewHolder(@NonNull View itemView) {
            super(itemView);
            imgVersionLogo = itemView.findViewById(R.id.imgVersionLogo);
            tvCodeName = itemView.findViewById(R.id.tvCodeName);
            tvVersionNumber = itemView.findViewById(R.id.tvVersionNumber);
            cardView = itemView.findViewById(R.id.cardView);
        }
    }
}