package com.example.androidversions;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.androidversions.AndroidVersion;
import com.example.androidversions.VersionAdapter;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerViewVersions;
    private VersionAdapter versionAdapter;
    private List<AndroidVersion> androidVersionList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerViewVersions = findViewById(R.id.recyclerViewVersions);
        recyclerViewVersions.setLayoutManager(new LinearLayoutManager(this));
        androidVersionList = new ArrayList<>();
        androidVersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Donut", "1.6"));
        androidVersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Éclair", "2.0 – 2.1"));
        androidVersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Froyo", "2.2 – 2.2.3"));
        androidVersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Gingerbread", "2.3 – 2.3.7"));
        androidVersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Honeycomb", "3.0 – 3.2.6"));
        androidVersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Ice Cream Sandwich", "4.0 – 4.0.4"));
        androidVersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Jelly Bean", "4.1 – 4.3.1"));
        androidVersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "KitKat", "4.4 – 4.4.4"));
        androidVersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Lollipop", "5.0 – 5.1.1"));
        androidVersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Marshmallow", "6.0 – 6.0.1"));
        androidVersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Nougat", "7.0 – 7.1.2"));
        androidVersionList.add(new AndroidVersion(R.mipmap.ic_launcher, "Oreo", "8.0 – 8.1"));
        versionAdapter = new VersionAdapter(androidVersionList, this);
        recyclerViewVersions.setAdapter(versionAdapter);
    }
}