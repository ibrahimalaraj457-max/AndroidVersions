package com.example.androidversions;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

// استدعاء صريح جداً للتأكد من أن الكلاس يرى الموديل بدون أي لبس
import com.example.androidversions.AndroidVersion;

public class VersionAdapter extends RecyclerView.Adapter<VersionAdapter.VersionViewHolder> {

    private List<AndroidVersion> versionList;
    private Context context;

    public VersionAdapter(List<AndroidVersion> versionList, Context context) {
        this.versionList = versionList;
        this.context = context;
    }

    @NonNull
    @Override
    public VersionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_android_version, parent, false);
        return new VersionViewHolder(view);
    }

    /*@Override
    public void onBindViewHolder(@NonNull VersionViewHolder holder, int position) {
        AndroidVersion currentVersion = versionList.get(position);
        holder.tvCodeName.setText(currentVersion.getCodeName());
        holder.tvVersionNumber.setText("Version: " + currentVersion.getVersion());
        holder.imgVersionLogo.setImageResource(currentVersion.getImageResId());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = "You selected: " + currentVersion.getCodeName() + " (" + currentVersion.getVersion() + ")";
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
            }
        });
    }*/
    @Override
    public void onBindViewHolder(@NonNull VersionViewHolder holder, int position) {
        AndroidVersion currentVersion = versionList.get(position);
        holder.tvCodeName.setText(currentVersion.getCodeName());
        holder.tvVersionNumber.setText("Version: " + currentVersion.getVersion());
        holder.imgVersionLogo.setImageResource(currentVersion.getImageResId());

        // ---- الميزة المتقدمة: تلوين الصفوف المتبادلة ----
        // ---- ميزة تلوين الكروت المتبادلة المتقدمة ----
        if (position % 2 == 0) {
            // الصفوف الزوجية: رمادي فاتح وناعم جداً يليق بالتصميم
            holder.cardView.setCardBackgroundColor(android.graphics.Color.parseColor("#a9a9a9"));
        } else {
            // الصفوف الفردية: اللون الأبيض الساطع
            holder.cardView.setCardBackgroundColor(android.graphics.Color.parseColor("#FFFFFF"));
        }
        // --------------------------------------------------

        // حدث الضغط على العنصر
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = "You selected: " + currentVersion.getCodeName() + " (" + currentVersion.getVersion() + ")";
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return versionList != null ? versionList.size() : 0;
    }

    /*public static class VersionViewHolder extends RecyclerView.ViewHolder {
        ImageView imgVersionLogo;
        TextView tvCodeName;
        TextView tvVersionNumber;

        public VersionViewHolder(@NonNull View itemView) {
            super(itemView);
            imgVersionLogo = itemView.findViewById(R.id.imgVersionLogo);
            tvCodeName = itemView.findViewById(R.id.tvCodeName);
            tvVersionNumber = itemView.findViewById(R.id.tvVersionNumber);
        }
    }*/
    public static class VersionViewHolder extends RecyclerView.ViewHolder {
        ImageView imgVersionLogo;
        TextView tvCodeName;
        TextView tvVersionNumber;
        androidx.cardview.widget.CardView cardView; // <--- أضف هذا السطر هنا

        public VersionViewHolder(@NonNull View itemView) {
            super(itemView);
            imgVersionLogo = itemView.findViewById(R.id.imgVersionLogo);
            tvCodeName = itemView.findViewById(R.id.tvCodeName);
            tvVersionNumber = itemView.findViewById(R.id.tvVersionNumber);
            cardView = itemView.findViewById(R.id.cardView); // <--- وأضف هذا السطر هنا للربط
        }
    }
}